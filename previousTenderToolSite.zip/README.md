# Startup Template

[See demo](http://mattmcneeney.github.io/startup-template/)

A simple responsive web page template that can be used to set up a web page that looks like every other web page on the bloody web.

Feel free to play around and contribute as much as you'd like. Note that this is supposed to be as barebones as possible (no task runners, minification, etc).

Advantages:
- You can be totally generic
- You can look like everyone else on the web
- People can forget who you are


Follow [@1mattmc](//twitter.com/1mattmc) for boring life updates.

## Version

1.0.0
